package com.example.ftcl;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

public class ProgressLayout extends AppCompatActivity {
    ImageView recLoc;
    View OnLoc;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.recycler_item);
//        recLoc = findViewById(R.id.recLoc);
//        recLoc.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                Uri uri = Uri. parse("https://chat.openai.com/chat"); // missing 'http://' will cause crashed
//                Intent intent = new Intent(Intent. ACTION_VIEW, uri);
//                startActivity(intent);
////                String url = "https://chat.openai.com/chat";
////                Intent intent = new Intent(Intent.ACTION_VIEW);
////                intent.setData(Uri.parse(url));
////                startActivity(intent);
//            }
//        });

//        OnLoc.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                Uri uri = Uri. parse("https://chat.openai.com/chat"); // missing 'http://' will cause crashed
//                Intent intent = new Intent(Intent. ACTION_VIEW, uri);
//                startActivity(intent);aaaaaaaaaaaaaa
//            }
//        });

    }
}